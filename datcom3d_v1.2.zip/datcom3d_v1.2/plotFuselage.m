%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% datcom3d Version 1.2                                                %%
% March 10, 2008                                                      %%
% Created By: Jafar Mohammed                                          %%
% File: plotFuselage.m                                                %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Inputs:
%   NX - number of fuselage stations
%   Xs - X values at each station (Array of length NX)
%    S - cross-sectional area at each station (Array of length NX)
%    R - fuselage half-width at each station (Array of length NX)
%   ZU - Upper Z-coordinate at each station (Array of length NX)
%   ZL - Lower Z-coordinate at each station (Array of length NX)
%    n - fuselage resolution (meshgrid)
function plotFuselage(NX,Xs,S,R,ZU,ZL,n)

ZC = [];
X = [];
Y = [];
Z = [];

% The following is taken from DATPLOT to get the coordinates
% of the fuselage.  Please refer to that document for the details
% of this code.

%The center of each fuselage cross section is calculated
for i=1:1:NX
   ZC(i) = (ZU(i)+ZL(i))*.5; 
end

%Get Y and Z coordinates
for j=1:1:NX
    W = R(j);
    if (W == 0)
        W = sqrt(S(j)/pi);
    end
    if (ZU(j) == 0)
       ZU(j)=W;
       ZL(j)=-W;
    end
    H = (ZU(j)-ZL(j))*.5; 
    WW=W*W;
    if (W == 0)
        WW = W;
    end
    HH=H*H;
    if (H == 0)
        HH = H;
    end
    WH=0;
    if ((W ~= 0) && (H ~= 0))
        WH=W*H;
    end
    GX2=pi/(n-1);
    for k=1:1:n
        THETA=(k-1)*GX2;
        RHO=0;
        if (WH ~= 0)
            RHO = WH/(sqrt(HH*(sin(THETA)^2)+WW*(cos(THETA)^2)));
        end
        Z(j,k)=RHO*cos(THETA)+ZC(j);
        Y(j,k)=RHO*sin(THETA);
    end
end
for i=1:n
    for j=1:NX
        X(i,j) = Xs(j);
    end
end

% Plot right and left halves of fuselage using SURF command
surf(X',Y,Z,'EdgeColor','k','DisplayName','Fuselage Stb.')
surf(X',-1.*Y,Z,'EdgeColor','k','DisplayName','Fuselage Port')